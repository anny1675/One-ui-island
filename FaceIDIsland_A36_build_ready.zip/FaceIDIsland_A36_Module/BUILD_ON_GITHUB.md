# Build the APK using GitHub Actions (phone-friendly)

This source ZIP does not include a Gradle wrapper, and the local execution environment used to inspect it has no Android SDK/Gradle installation or network access. The included GitHub Actions workflow builds the APK in GitHub's cloud runner.

1. On GitHub, create a new **private** repository (recommended for an unpublished project).
2. Extract this ZIP on your phone using a ZIP/file manager.
3. Open the `FaceIDIsland_A36_Module` folder and upload its contents (including the hidden `.github` folder) to the repository root. If the mobile upload flow hides `.github`, create `.github/workflows/build-apk.yml` on GitHub and paste the contents of the included workflow file.
4. Open the repository's **Actions** tab. Select **Build FaceID Island APK** and tap **Run workflow**. A push to `main` or `master` also starts a build automatically.
5. When the run completes successfully, open that run, scroll to **Artifacts**, and download `FaceIDIsland-debug-apk`. Extract it to obtain `app-debug.apk`.

The workflow uses JDK 17, Gradle 8.9, Android SDK 35, and runs `gradle :app:assembleDebug`.

A successful build only proves that the APK compiled. This module remains experimental and untested on real Samsung firmware. The source targets Galaxy A36 (SM-A366B); compatibility with Galaxy M34 (SM-M346B) is not established. Do not enable it in LSPosed on a primary device until compatibility has been checked.
