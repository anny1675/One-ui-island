# FaceID Island — Samsung A36 experimental LSPosed module

**Status: experimental source project; not compiled or tested on an A36.**

Target: Samsung Galaxy A36 5G (SM-A366B), One UI 9 / Android 17 as reported by the device owner. Scope this module to `com.android.systemui` only.

## What it does
Hooks the SystemUI `KeyguardUpdateMonitor` face-success methods (`onFaceAuthenticated` and `handleFaceAuthenticated`) and attempts to display a short, non-interactive face/check animation using a SystemUI-owned overlay window. It does not authenticate, bypass, or dismiss the keyguard itself. Samsung's own biometric system remains responsible for unlocking.

## Build
Open this folder as a Gradle Android project in Android Studio or a compatible Android Gradle environment. Use JDK 17 and Android SDK 35 or newer. Run:

```bash
./gradlew :app:assembleDebug
```

On Windows:

```powershell
.\gradlew.bat :app:assembleDebug
```

Expected output after a successful build: `app/build/outputs/apk/debug/app-debug.apk`.

## Install
1. Install the APK normally (it is an Xposed module container app).
2. In LSPosed, enable **Face ID Island Module**.
3. Set its scope to **System UI** (`com.android.systemui`) only.
4. Reboot or restart SystemUI.
5. Test with the phone locked and your enrolled face.

## Important compatibility notes
- Samsung's One UI SystemUI is proprietary and may rename, move, or change the relevant methods. If LSPosed logs `no known face-auth method found`, the hook must be adapted to that firmware's SystemUI classes.
- If the hook runs but the overlay does not appear, `TYPE_STATUS_BAR_SUB_PANEL` may be restricted or unsupported on this build; inspect LSPosed logs and logcat before changing window types.
- The animation is triggered on the success callback, not while the camera is scanning. It may appear very briefly or be hidden by the immediate keyguard dismissal. Timing and window layering require on-device testing.
- This project is source only. No APK has been built or validated in this environment.
