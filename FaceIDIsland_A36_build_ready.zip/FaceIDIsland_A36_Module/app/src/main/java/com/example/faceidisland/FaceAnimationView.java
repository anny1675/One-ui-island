package com.example.faceidisland;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

public final class FaceAnimationView extends View {
    private final Paint p = new Paint(3);
    private float progress = 0f;
    private float check = 0f;
    private Runnable finish;

    public FaceAnimationView(Context c) {
        super(c);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void start(Runnable onFinish) {
        finish = onFinish;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(1050);
        a.setInterpolator(new DecelerateInterpolator());
        a.addUpdateListener(v -> { progress = (float) v.getAnimatedValue(); invalidate(); });
        a.start();
        postDelayed(() -> {
            ValueAnimator b = ValueAnimator.ofFloat(0f, 1f);
            b.setStartDelay(520); b.setDuration(260);
            b.addUpdateListener(v -> { check = (float) v.getAnimatedValue(); invalidate(); });
            b.start();
        }, 0);
        postDelayed(() -> { if (finish != null) finish.run(); }, 1550);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float cx = getWidth()/2f, cy = getHeight()/2f;
        float radius = Math.min(getWidth(), getHeight()) * .36f;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0x5539D9FF); c.drawCircle(cx, cy, radius, p);
        p.setColor(0xFF45DFFF); p.setShadowLayer(dp(14), 0, 0, 0xAA28CFFF);
        c.drawArc(new RectF(cx-radius, cy-radius, cx+radius, cy+radius), -90, 360*progress, false, p);
        p.clearShadowLayer();
        // Minimal geometric face glyph.
        p.setColor(0xFFEAFBFF); p.setStrokeWidth(dp(3));
        Path face = new Path();
        face.moveTo(cx-dp(42),cy-dp(36)); face.quadTo(cx-dp(53),cy, cx-dp(35),cy+dp(43));
        face.quadTo(cx,cy+dp(65),cx+dp(35),cy+dp(43)); face.quadTo(cx+dp(53),cy,cx+dp(42),cy-dp(36));
        c.drawPath(face,p);
        c.drawLine(cx-dp(22),cy-dp(8),cx-dp(9),cy-dp(8),p);
        c.drawLine(cx+dp(9),cy-dp(8),cx+dp(22),cy-dp(8),p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3));
        c.drawArc(new RectF(cx-dp(14),cy+dp(4),cx+dp(14),cy+dp(28)), 15,150,false,p);
        if (check > 0) {
            p.setColor(0xFF59F29A); p.setStrokeWidth(dp(5));
            Path tick = new Path(); tick.moveTo(cx-dp(15),cy+dp(83));
            tick.lineTo(cx-dp(3),cy+dp(95)); tick.lineTo(cx+dp(20),cy+dp(69));
            c.drawPath(tick,p);
        }
    }
    private float dp(float x) { return x*getResources().getDisplayMetrics().density; }
}
