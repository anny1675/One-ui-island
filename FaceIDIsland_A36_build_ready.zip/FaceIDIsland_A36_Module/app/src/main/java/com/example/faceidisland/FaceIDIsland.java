package com.example.faceidisland;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicLong;

import de.robv.android.xposed.AndroidAppHelper;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class FaceIDIsland implements IXposedHookLoadPackage {
    private static final String TAG = "FaceIDIsland";
    private static final AtomicLong LAST_SHOWN = new AtomicLong(0);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        try {
            Class<?> monitor = XposedBridge.class.getClassLoader() == null
                    ? Class.forName("com.android.keyguard.KeyguardUpdateMonitor")
                    : lpparam.classLoader.loadClass("com.android.keyguard.KeyguardUpdateMonitor");
            int hooked = 0;
            for (Method method : monitor.getDeclaredMethods()) {
                String name = method.getName();
                // Samsung/AOSP variants: these methods are reached only after successful face auth.
                if ("onFaceAuthenticated".equals(name) || "handleFaceAuthenticated".equals(name)) {
                    XposedBridge.hookMethod(method, new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam param) {
                            showFromSystemUi(param.thisObject);
                        }
                    });
                    hooked++;
                }
            }
            XposedBridge.log(TAG + ": hooked face-auth success methods=" + hooked);
            if (hooked == 0) XposedBridge.log(TAG + ": no known face-auth method found; firmware hook needs adapting");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook setup failed: " + t);
        }
    }

    private static void showFromSystemUi(Object monitor) {
        long now = android.os.SystemClock.uptimeMillis();
        long previous = LAST_SHOWN.get();
        if (now - previous < 1200 || !LAST_SHOWN.compareAndSet(previous, now)) return;
        MAIN.post(() -> {
            try {
                Context context = (Context) XposedHelpersCompat.getContext(monitor);
                if (context == null) return;
                WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
                if (wm == null) return;
                FaceAnimationView view = new FaceAnimationView(context);
                int size = (int) (260 * context.getResources().getDisplayMetrics().density);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                        size, size,
                        WindowManager.LayoutParams.TYPE_STATUS_BAR_SUB_PANEL,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.CENTER;
                lp.setTitle("FaceIDIsland");
                wm.addView(view, lp);
                view.start(() -> {
                    try { wm.removeView(view); } catch (Throwable ignored) { }
                });
            } catch (Throwable t) {
                XposedBridge.log(TAG + ": overlay failed: " + t);
            }
        });
    }

    // Kept separate to avoid depending on hidden fields; SystemUI's application context is used.
    private static final class XposedHelpersCompat {
        static Context getContext(Object ignored) {
            try {
                return AndroidAppHelper.currentApplication();
            } catch (Throwable t) { return null; }
        }
    }
}
